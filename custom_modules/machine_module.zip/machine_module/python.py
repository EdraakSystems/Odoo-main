def prin():
    print("I ran");

prin()